package ch.hsr.bieridee.domain.interfaces;

/**
 * Unified interface for domain models.
 */
public interface IDomain {

}
