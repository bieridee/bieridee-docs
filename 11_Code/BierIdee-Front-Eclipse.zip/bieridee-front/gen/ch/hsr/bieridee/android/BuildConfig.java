/** Automatically generated file. DO NOT MODIFY */
package ch.hsr.bieridee.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}